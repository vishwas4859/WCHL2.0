# Code Citations

## License: unknown
https://github.com/Lunar-spec/earthWander/blob/1d28f31b5df9a4268c5a35183168346cf17aa4ed/client/src/pages/Flights/Flights.jsx

```
text"
        
```


## License: unknown
https://github.com/Lunar-spec/earthWander/blob/1d28f31b5df9a4268c5a35183168346cf17aa4ed/client/src/pages/Flights/Flights.jsx

```
text"
        placeholder="From
```


## License: unknown
https://github.com/Lunar-spec/earthWander/blob/1d28f31b5df9a4268c5a35183168346cf17aa4ed/client/src/pages/Flights/Flights.jsx

```
text"
        placeholder="From"
        value
```


## License: unknown
https://github.com/Lunar-spec/earthWander/blob/1d28f31b5df9a4268c5a35183168346cf17aa4ed/client/src/pages/Flights/Flights.jsx

```
text"
        placeholder="From"
        value={fromLocation}
```


## License: unknown
https://github.com/Lunar-spec/earthWander/blob/1d28f31b5df9a4268c5a35183168346cf17aa4ed/client/src/pages/Flights/Flights.jsx

```
text"
        placeholder="From"
        value={fromLocation}
        onChange={(
```


## License: unknown
https://github.com/Lunar-spec/earthWander/blob/1d28f31b5df9a4268c5a35183168346cf17aa4ed/client/src/pages/Flights/Flights.jsx

```
text"
        placeholder="From"
        value={fromLocation}
        onChange={(e) => set
```


## License: unknown
https://github.com/Lunar-spec/earthWander/blob/1d28f31b5df9a4268c5a35183168346cf17aa4ed/client/src/pages/Flights/Flights.jsx

```
text"
        placeholder="From"
        value={fromLocation}
        onChange={(e) => setFromLocation(e
```


## License: unknown
https://github.com/Lunar-spec/earthWander/blob/1d28f31b5df9a4268c5a35183168346cf17aa4ed/client/src/pages/Flights/Flights.jsx

```
text"
        placeholder="From"
        value={fromLocation}
        onChange={(e) => setFromLocation(e.target.value
```


## License: unknown
https://github.com/Lunar-spec/earthWander/blob/1d28f31b5df9a4268c5a35183168346cf17aa4ed/client/src/pages/Flights/Flights.jsx

```
text"
        placeholder="From"
        value={fromLocation}
        onChange={(e) => setFromLocation(e.target.value)}
      />
```


## License: unknown
https://github.com/Lunar-spec/earthWander/blob/1d28f31b5df9a4268c5a35183168346cf17aa4ed/client/src/pages/Flights/Flights.jsx

```
text"
        placeholder="From"
        value={fromLocation}
        onChange={(e) => setFromLocation(e.target.value)}
      />
      <input
```


## License: unknown
https://github.com/Lunar-spec/earthWander/blob/1d28f31b5df9a4268c5a35183168346cf17aa4ed/client/src/pages/Flights/Flights.jsx

```
text"
        placeholder="From"
        value={fromLocation}
        onChange={(e) => setFromLocation(e.target.value)}
      />
      <input
        type="
```


## License: unknown
https://github.com/Lunar-spec/earthWander/blob/1d28f31b5df9a4268c5a35183168346cf17aa4ed/client/src/pages/Flights/Flights.jsx

```
text"
        placeholder="From"
        value={fromLocation}
        onChange={(e) => setFromLocation(e.target.value)}
      />
      <input
        type="text"
        
```


## License: unknown
https://github.com/Lunar-spec/earthWander/blob/1d28f31b5df9a4268c5a35183168346cf17aa4ed/client/src/pages/Flights/Flights.jsx

```
text"
        placeholder="From"
        value={fromLocation}
        onChange={(e) => setFromLocation(e.target.value)}
      />
      <input
        type="text"
        placeholder="To"
```


## License: unknown
https://github.com/Lunar-spec/earthWander/blob/1d28f31b5df9a4268c5a35183168346cf17aa4ed/client/src/pages/Flights/Flights.jsx

```
text"
        placeholder="From"
        value={fromLocation}
        onChange={(e) => setFromLocation(e.target.value)}
      />
      <input
        type="text"
        placeholder="To"
        value={
```


## License: unknown
https://github.com/Lunar-spec/earthWander/blob/1d28f31b5df9a4268c5a35183168346cf17aa4ed/client/src/pages/Flights/Flights.jsx

```
text"
        placeholder="From"
        value={fromLocation}
        onChange={(e) => setFromLocation(e.target.value)}
      />
      <input
        type="text"
        placeholder="To"
        value={toLocation}
```


## License: unknown
https://github.com/Lunar-spec/earthWander/blob/1d28f31b5df9a4268c5a35183168346cf17aa4ed/client/src/pages/Flights/Flights.jsx

```
text"
        placeholder="From"
        value={fromLocation}
        onChange={(e) => setFromLocation(e.target.value)}
      />
      <input
        type="text"
        placeholder="To"
        value={toLocation}
        onChange={(e
```


## License: unknown
https://github.com/Lunar-spec/earthWander/blob/1d28f31b5df9a4268c5a35183168346cf17aa4ed/client/src/pages/Flights/Flights.jsx

```
text"
        placeholder="From"
        value={fromLocation}
        onChange={(e) => setFromLocation(e.target.value)}
      />
      <input
        type="text"
        placeholder="To"
        value={toLocation}
        onChange={(e) => setTo
```


## License: unknown
https://github.com/Lunar-spec/earthWander/blob/1d28f31b5df9a4268c5a35183168346cf17aa4ed/client/src/pages/Flights/Flights.jsx

```
text"
        placeholder="From"
        value={fromLocation}
        onChange={(e) => setFromLocation(e.target.value)}
      />
      <input
        type="text"
        placeholder="To"
        value={toLocation}
        onChange={(e) => setToLocation(e.
```


## License: unknown
https://github.com/Lunar-spec/earthWander/blob/1d28f31b5df9a4268c5a35183168346cf17aa4ed/client/src/pages/Flights/Flights.jsx

```
text"
        placeholder="From"
        value={fromLocation}
        onChange={(e) => setFromLocation(e.target.value)}
      />
      <input
        type="text"
        placeholder="To"
        value={toLocation}
        onChange={(e) => setToLocation(e.target.value)}
```


## License: unknown
https://github.com/Lunar-spec/earthWander/blob/1d28f31b5df9a4268c5a35183168346cf17aa4ed/client/src/pages/Flights/Flights.jsx

```
text"
        placeholder="From"
        value={fromLocation}
        onChange={(e) => setFromLocation(e.target.value)}
      />
      <input
        type="text"
        placeholder="To"
        value={toLocation}
        onChange={(e) => setToLocation(e.target.value)}
      />
```


## License: unknown
https://github.com/Lunar-spec/earthWander/blob/1d28f31b5df9a4268c5a35183168346cf17aa4ed/client/src/pages/Flights/Flights.jsx

```
text"
        placeholder="From"
        value={fromLocation}
        onChange={(e) => setFromLocation(e.target.value)}
      />
      <input
        type="text"
        placeholder="To"
        value={toLocation}
        onChange={(e) => setToLocation(e.target.value)}
      />
      <
```

